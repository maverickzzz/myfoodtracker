-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 14, 2017 at 07:41 PM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `maverick_myfoodtracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `track_date`
--

DROP TABLE IF EXISTS `track_date`;
CREATE TABLE IF NOT EXISTS `track_date` (
  `history_date` date NOT NULL,
  `det_morning` text COLLATE utf8_unicode_ci,
  `det_afternoon` text COLLATE utf8_unicode_ci,
  `det_evening` text COLLATE utf8_unicode_ci,
  `uihong_severity_morning` tinyint(1) NOT NULL,
  `uihong_severity_afternoon` tinyint(1) NOT NULL,
  `uihong_severity_evening` tinyint(1) NOT NULL,
  `got_poop` tinyint(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_date`
--

INSERT INTO `track_date` (`history_date`, `det_morning`, `det_afternoon`, `det_evening`, `uihong_severity_morning`, `uihong_severity_afternoon`, `uihong_severity_evening`, `got_poop`) VALUES
('2017-08-21', '["sosis","roti cane","timun","roti coklat"]', '["Kari","Bihun","Semangka","Ayam","Kentang","Krupuk lidi"]', '["Cake","Ubi","Krupuk cap ikan","Cabe korek","Udang","Markisa"]', 2, 0, 0, 1),
('2017-08-22', '["Roti","Keju","Coklat"]', '["Soto","Krupuk lidi","Cabe"]', '["Nasi lemak","Telur goreng"]', 2, 0, 0, 1),
('2017-08-23', '["Nasi lemak","Telur","Roti ham","Roti keju"]', '["Bistik ayam"]', '["Nugget","Durian"]', 1, 1, 2, 1),
('2017-08-24', '["Nasi","Tahu","Tempe","Lodeh","Jagung","Taoge","Labu","Kentang","Serundeng kelapa","Urap"]', '["Watfen","Kwetiaw"]', '["Bakpau"]', 2, 2, 2, 1),
('2017-08-25', '["Bihun","Telur","Roti"]', '["Sangwo"]', '["Durian","Nenas","Sayur","Teri"]', 1, 1, 1, 1),
('2017-08-26', '["Roti","Sapi","Keju","Telur"]', '["Ikan","Cabe"]', '["Mi pangsit","Lemon"]', 1, 2, 2, 1),
('2017-08-27', '["Kari","Bihun"]', '["Durian","Kue lobak","Sushi","Salmon"]', '["Steak","Beef","Kentang","Gorengan","Jagung","Buncis","Yogurt","Granola"]', 0, 1, 2, 0),
('2017-08-28', '["Pokpia"]', '["Ayam wijen","Gorengan","Kol","Sayur","Semangka"]', '["Telur","Spagethi","Jamur","Keju","Durian","Cabe rawit"]', 1, 1, 2, 0),
('2017-08-29', '["Spagethi","Keju","Jamur","Bakpau","Telur asin","Cha shio"]', '["Rendang","Sayur","Semangka","Kulit tahu"]', '["Semangka","Teri","Pete","Telur","Tomat","Gorengan"]', 1, 1, 2, 1),
('2017-08-30', '["burger","daging ayam burger fiesta","mie pansit"]', '["Nasi goreng","Telur","Krupuk","Krupuk cabe","Semangka"]', '["Edamame","Kacang","Krupuk pedas","Krupuk","Cabe","Chicken holic","Kerang","Sate kerang","Ayam rendang","Urap","Kelapa","Sayur"]', 2, 2, 2, 0),
('2017-08-31', '["Babi","Ubi","Roti","Marie","Biskuit"]', '["Daun ubi","Sayur","Ayam jahe","Semangka","Tomat","Mamee"]', '["Mie","Kwetiaw","Telur","Roti cane"]', 1, 1, 2, 1),
('2017-09-04', '["Roti","Abon"]', '["Ayam goreng","Tempe","Gorengan","Sambal","Sayur asem","Jagung"]', '["Kwe2","Bihun","Teri"]', 2, 2, 2, 1),
('2017-09-02', '["Semangka"]', '["Beef burger","Roti","Kari","Sapi","Ayam goreng","Cream soup","Es","Nata de coco","Mangga","Jelly"]', '', 0, 2, 2, 1),
('2017-09-01', '["Spagethi","Keju"]', '["Ayam penyet","Cabe"]', '["Mayo","Salmon","Keju","Semangka","Samyang","Cabe","Udang"]', 1, 1, 2, 0),
('2017-09-03', '', '["Sushi","Gorengan","Kol","Salad","Salmon","Mi cha2","Green tea"]', '["Kari","Sapi","Durian"]', 2, 2, 2, 0),
('2017-09-07', '["Sapi","Jagung"]', '["Gorengan","Bakwan kol","Ayam jahe","Sayur"]', '["Ikan goreng","Asam manis","Pir"]', 3, 3, 3, 0),
('2017-09-05', '["Samyang","Cabe","Nasi","Jagung","Sapi","Indomie","Keju"]', '["Mi rebus"]', '["Teri","Sambal","Babi","Coklat","Permen"]', 2, 2, 2, 1),
('2017-09-06', '["Telur rebus","Telur","Roti","Skippy"]', '["Bistik","Agar","Roti"]', '["Ayam goreng","Nasi padang","Kari kambing","Es","Slushee"]', 2, 2, 2, 1),
('2017-09-08', '["Spagethi","Bolognese","Jagung","Roti","Sosis ham","Sosis"]', '["Ayam goreng","Sambal","Pepaya"]', '["Pia kacang","Sushi","Mayo","Kepiting"]', 3, 3, 3, 1),
('2017-09-09', '["sapi","ubi"]', '["kentang","rendang sapi","ayam telur asin"]', '["Mcd","Burger","Soda"]', 3, 3, 2, 1),
('2017-09-10', '', '["Durian","Mi","Cha2","Tauge","Lobak"]', '["Indomie","Jelly"]', 2, 2, 2, 0),
('2017-09-11', '["Indomie","Telur"]', '["Ayam goreng","Kentang cabe","Rumput laut sop","Buncis","Timun","Yogurt"]', '["Chun kien","Telur goreng","Sambal"]', 2, 2, 2, 1),
('2017-09-12', '["Roti","Telur"]', '["Ayam kecap","Bakwan jagung","Gorengan"]', '["Roti","Indomie"]', 2, 1, 1, 1),
('2017-09-13', '["Nasi sayur","Nangka","Telur","Kentang"]', '["Ayam goreng","Saus plum","Sayur","Sawi","Bakwan jagung","Gorengan"]', '["Nasi padang","Telur","Sambal","Roti","es krim"]', 1, 1, 1, 0),
('2017-09-14', '["Spagethi","Sapi","Roti"]', '["Ayam semur","Tempe goreng","Sayur","Kol","Gorengan"]', '["Kfc","Soda"]', 2, 2, 2, 1),
('2017-09-15', '["bubur","roti","bolognese"]', '["gorengan","bakwan kol","ayam lengkuas","ayam goreng","martabak","aleo vera","orong orong"]', '', 3, 3, 3, 1),
('2017-09-16', '["Indomie","Babi","Kacang polong","Wortel"]', '["Kulit tahu","Rendang sapi"]', '["Roti","Burger sapi","Kentang goreng","Dimsum","Kaki ayam","Lenghongkien","Mayo","Xiao long bao"]', 3, 3, 3, 1),
('2017-09-17', '', '["Ayam goreng","A&w","Ak bihun","Bihun","Bebek","Thai ice tea"]', '["Burger","Roti","Ayam"]', 3, 3, 3, 0),
('2017-09-18', '["Telur","Roti","Orong2","Nasi sayur"]', '["Ikan sambel","Gorengan","Bakwan jagung","Sawi","Buah naga"]', '["Kwekwe","Sushi"]', 2, 2, 2, 1),
('2017-09-19', '["Sushi","Bolu"]', '["Bihun goreng","Telur goreng","Kulit tahu"]', '["Mie","Bakpau","Babi","Risol","Gogo"]', 2, 2, 2, 1),
('2017-09-20', '["Ubi","Telor goreng"]', '["Sate padang","Pisang","Pir"]', '["Kwekwe","Baso goreng","Bakwan kol","Gorengan","Ayam goreng"]', 1, 2, 2, 1),
('2017-09-21', '["Tortila","Sosis","Telur goreng"]', '["Tiongsim","Pir"]', '["Tiongsim"]', 1, 2, 2, 1),
('2017-09-22', '["Pizza","Roti","Aloe vera"]', '["Ayam semur","Serundeng ayam","Bakpau","Pir"]', '["Ayam goreng","Tempe","Cumi goreng"]', 1, 2, 2, 1),
('2017-09-23', '["Indomie","Telur"]', '["Kulit tahu","Kacang merah","Sop"]', '["Pepperlunch","Hotplate","Tauge","Sapi","Jagung","Kacang panjang"]', 1, 3, 2, 1),
('2017-09-24', '', '["Nasi goreng","Bak phok","Kwetiaw","Eskrim"]', '["Eskrim","Ayam goreng","Sambal","Tempe goreng","Nasi goreng"]', 2, 2, 2, 0),
('2017-09-25', '["Roti goreng","Manthao"]', '["Ayam goreng","Sambal","Sayur asem","Jagung","Tempe goreng","Gorengan"]', '["Kepiting","Tauco","Tempe goreng"]', 2, 2, 2, 1),
('2017-09-26', '["Bakpau besar","Lapchiong","Telur asin","Cabe rawit","Bangun mulut pahit"]', '["Ayam semur","Bihun goreng","Sop rumput laut"]', '["Spaghetti","Semangka"]', 2, 2, 2, 1),
('2017-09-27', '["Pisang rebus","Pisang","Susu kental manis","Coklat"]', '["Ayam kecap","Kulit tahu","Sawi","Tempe","Sup rumput laut","Buah naga","Wakamoto"]', '["Ikan goreng","Mangga muda","Chunkien","Makanan pesta"]', 2, 2, 2, 1),
('2017-09-28', '["Bebek panggang","Croissant"]', '["Ayam semur"]', '["Martabak","Kari","Mpek2","Semangka","Bihun goreng"]', 2, 2, 3, 1),
('2017-09-29', '["Bihun goreng","Kwetiaw goreng","Telur","Roti","Keju"]', '', '["Bihun goreng","Kwekwe"]', 3, 2, 2, 1),
('2017-09-30', '', '["Pizza","Keju","Sate padang","Krupuk"]', '["Hotdog"]', 2, 3, 3, 1),
('2017-10-01', '["Bihun bebek","Martabak piring tipis"]', '["Kwetiaw"]', '["Ajep wedding"]', 3, 3, 3, 0),
('2017-10-02', '["Indomie","Telur"]', '["Nasi tim","Nenas","Melon","Belimbing"]', '["Indomie"]', 2, 2, 3, 1),
('2017-10-03', '["Bakpau","Kacang hitam"]', '["Bihun ayam"]', '["Bihun bebek"]', 2, 3, 3, 0),
('2017-10-04', '["Nasi vege","Sayur","Brokoli","Bunga kol","Nenas","Tauco"]', '["Nasi ayam"]', '["Kwetiaw goreng","Mangga"]', 2, 3, 2, 1),
('2017-10-05', '["Kue bulan"]', '["Wat fen"]', '["Bubur","Pekcamke","Telur asin"]', 2, 2, 2, 0),
('2017-10-06', '["Bubur"]', '["Bubur","Kue bulan","Telur asin"]', '["Bubur","Telur asin","Buah naga"]', 2, 3, 3, 0),
('2017-10-07', '["Bubur","Telur asin","Teri"]', '["Roti","Keju"]', '["Sushi"]', 2, 2, 2, 0),
('2017-10-08', '["Mie pangsit"]', '["Telur goreng","Sosis"]', '["Eskrim","Bihun ikan","Ikan goreng"]', 2, 3, 3, 0),
('2017-10-09', '["Roti","Telur goreng","Bacon"]', '["Ayam goreng saus plum","Semangka","Sayur"]', '["Ayam","Cabe kecap"]', 2, 2, 2, 1),
('2017-10-10', '["roti","ayam","kentang"]', '["Ayam cabe ebi","Buncis","Sop rumput laut"]', '["Kari kambing","Nugget"]', 2, 2, 2, 1),
('2017-10-11', '["Nasi goreng","Telur goreng"]', '["Bakwan kol","Ayam goreng sambal","Semangka","Kacang panjang"]', '["A&w","Cumi kecil cabe"]', 1, 1, 2, 1),
('2017-10-23', '["telur","roti"]', '["nasi tim"]', '["Sayur cina panjang2","Ayam kecap"]', 1, 1, 1, 1),
('2017-10-22', '["pisang"]', '["nasi ayam","chasio"]', '["kfc"]', 1, 1, 1, 0),
('2017-10-15', '', '["sop iga","kentang","ayam bakar"]', '', 0, 0, 0, 0),
('2017-10-24', '["Indomie"]', '["Mi rebus","Pisang","Roti","Selai blueberry"]', '["Ayam goreng saos cabe","Telur kukus"]', 1, 1, 1, 1),
('2017-10-25', '["Roti panggang","Bacon"]', '', '', 1, 0, 0, 1),
('2017-11-01', '["Nasi lemak","Kentang","Tauco"]', '["Nasi goreng","Rendang","Telur goreng"]', '["Sambal bawang","Nugget","buah naga"]', 1, 1, 1, 1),
('2017-11-02', '["Nasi sayur","Telur rebus","Tauco"]', '["bihun goreng","nasi garuda","ayam goreng","tempe goreng","sambal"]', '["ikan goreng","sambal korek","capcay","buah naga"]', 1, 1, 2, 1),
('2017-11-03', '["bakpau","roti"]', '["nasi goreng","telur goreng","semangka","buah naga","Lengkeng"]', '["Sop","Kentang","Ikan"]', 1, 1, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `track_date`
--
ALTER TABLE `track_date`
  ADD PRIMARY KEY (`history_date`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
